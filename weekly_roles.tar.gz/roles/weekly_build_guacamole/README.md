# weekly_build_guacamole

Weekly early-warning build of `guacamole`. Defines `weekly_component` in `defaults/main.yml`
and runs `weekly_common`. See that role for the steps and paths.
