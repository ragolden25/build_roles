# weekly_common

Shared task library behind every `weekly_build_<component>` role. Weekly builds are early
warning only: they read the quarter build directories and staged content and never write into
a quarter directory.

Steps (`tasks/main.yml`): context -> directories -> detect_version -> prepare -> build -> scan -> finish.
`finish` always runs (result.env, remove the weekly images, prune old weeks, report to the dashboard).

Input: the `weekly_component` dictionary defined in each `weekly_build_<component>` role.
Settings and paths: `defaults/main.yml` (quarter/week auto-detected unless `weekly_quarter` / `weekly_week` are set).
