# weekly_build_grafana

Weekly early-warning build of `grafana`. Defines `weekly_component` in `defaults/main.yml`
and runs `weekly_common`. See that role for the steps and paths.
