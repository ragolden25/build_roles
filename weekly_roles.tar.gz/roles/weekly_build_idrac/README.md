# weekly_build_idrac

Weekly early-warning build of `idrac`. Defines `weekly_component` in `defaults/main.yml`
and runs `weekly_common`. See that role for the steps and paths.
