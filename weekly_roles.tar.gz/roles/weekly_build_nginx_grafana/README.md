# weekly_build_nginx_grafana

Weekly early-warning build of `nginx_grafana`. Defines `weekly_component` in `defaults/main.yml`
and runs `weekly_common`. See that role for the steps and paths.
