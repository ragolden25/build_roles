# weekly_build_postgres

Weekly early-warning build of `postgres`. Defines `weekly_component` in `defaults/main.yml`
and runs `weekly_common`. See that role for the steps and paths.
