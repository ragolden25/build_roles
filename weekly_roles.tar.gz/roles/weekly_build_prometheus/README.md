# weekly_build_prometheus

Weekly early-warning build of `prometheus`. Defines `weekly_component` in `defaults/main.yml`
and runs `weekly_common`. See that role for the steps and paths.
