# weekly_build_nginx_guac

Weekly early-warning build of `nginx_guac`. Defines `weekly_component` in `defaults/main.yml`
and runs `weekly_common`. See that role for the steps and paths.
