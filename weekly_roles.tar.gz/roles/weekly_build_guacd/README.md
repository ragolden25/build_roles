# weekly_build_guacd

Weekly early-warning build of `guacd`. Defines `weekly_component` in `defaults/main.yml`
and runs `weekly_common`. See that role for the steps and paths.
